<?php
/**
 * Payleap Payment CC Types Source Model
 *
 * @category    Vds
 * @package     Vds_Payleap
 * @author      Scott Logsdon <scott.logsdon@vdevsource.com>
 */
class Vds_Payleap_Model_Source_Cctype extends Mage_Payment_Model_Source_Cctype
{
    public function getAllowedTypes()
    {
        return array('VI', 'MC', 'AE', 'DI');
    }
}