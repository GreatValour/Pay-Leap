<?php
/**
 * Payleap Payment Model
 *
 * @category    Vds
 * @package     Vds_Payleap
 * @author      Scott Logsdon <scott.logsdon@vdevsource.com>
 */
class Vds_Payleap_Model_Mysql4_Payleap_Debug_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract 
{
	protected function _construct()
	{
		$this->_init('payleap/payleap_debug');
	}
}