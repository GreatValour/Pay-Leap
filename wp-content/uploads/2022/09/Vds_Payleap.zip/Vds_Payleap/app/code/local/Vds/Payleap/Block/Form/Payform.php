<?php

class Vds_Payleap_Block_Form_Payform extends Mage_Payment_Block_Form_Cc
{
    protected function _construct()  
	{
		parent::_construct();
		$this->setTemplate('payleap/form/payform.phtml');
	}
   
        
}
?>
