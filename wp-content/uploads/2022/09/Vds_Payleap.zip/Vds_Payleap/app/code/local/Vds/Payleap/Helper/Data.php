<?php
/**
 * Payleap Payment Helper
 *
 * @category    Vds
 * @package     Vds_Payleap
 * @author      Scott Logsdon <scott.logsdon@vdevsource.com>
 */
class Vds_Payleap_Helper_Data extends Mage_Payment_Helper_Data
{
	
}